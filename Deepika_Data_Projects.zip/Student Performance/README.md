# 🎓 Student Performance Prediction

**Tools Used:** Excel  
**Skills Applied:** Correlation Analysis, Score Matrix

## 🔍 Project Summary
Explored how attendance and study hours affect student grades using structured data.

## 📊 Key Insights
- Attendance above 85% directly links to better performance
- Weak subjects identified for targeted tutoring
- Score matrix built to prioritize efforts

🎯 Can help educators guide student success with data.
