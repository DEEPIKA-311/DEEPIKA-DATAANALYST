# 📋 Survey Data Visualization

**Tools Used:** Excel  
**Skills Applied:** Charts, Conditional Formatting, Storytelling

## 🔍 Project Summary
Analyzed survey responses using Excel to generate clean visuals and summaries of participant behavior.

## 📊 Key Insights
- 70% prefer online shopping over offline
- Majority users aged 18–25
- Brand awareness is highly impacted by social media

🎯 Great for product teams to understand audience insights.
