# 📺 Netflix User Behaviour Analysis

**Tools Used:** Excel, Power BI  
**Skills Applied:** Data Cleaning, Dashboarding, Insights

## 🔍 Project Summary
This project analyzes user behavior and preferences using Netflix viewership data. The dashboard provides insights into top genres, peak hours, and user engagement levels.

## 📊 Key Insights
- Top 3 most-watched genres: Drama, Thriller, Comedy
- Majority of viewing happens in evenings
- Repeat viewing patterns spotted in younger age groups

🎯 Built for real-time understanding of audience content taste.
