# 🦠 COVID-19 Data Analysis

**Tools Used:** Power BI  
**Skills Applied:** Slicer, KPI Cards, Time Series

## 🔍 Project Summary
This Power BI dashboard compares COVID-19 data across regions, including confirmed cases, recoveries, and deaths.

## 📊 Key Insights
- Region A showed highest peak in May 2021
- Recovery rate improved post vaccination phase
- Custom slicers added to analyze country-wise spread

🎯 Useful for public health decision making and awareness.
