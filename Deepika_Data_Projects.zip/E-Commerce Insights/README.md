# 🛍️ E-Commerce Sales Dashboard

**Tools Used:** Excel, Power BI  
**Skills Applied:** Dashboarding, Region-wise Analysis, KPIs

## 🔍 Project Summary
Created a dynamic dashboard to visualize sales performance across regions, categories, and time periods.

## 📊 Key Insights
- West region has the highest sales
- Electronics & Fashion are top-selling categories
- Sales peak during festive months

🎯 Helps business teams make better stock and marketing decisions.
